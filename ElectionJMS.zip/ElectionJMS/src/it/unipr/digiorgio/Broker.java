
package it.unipr.digiorgio;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerFactory;
import org.apache.activemq.broker.BrokerService;

/**
 * The {@code Broker} class sets up and starts an ActiveMQ broker with specific properties and establishes a
 * connection using ActiveMQConnectionFactory.
 * 
 * @author Matteo Di Giorgio 353719
 */

public class Broker {

	private static final String BROKER_URL = "tcp://localhost:61616"; // Default ActiveMQ broker URL
	private static final String BROKER_PROPS = "persistent=false&useJmx=false"; // Default ActiveMQ broker properties

	/**
	 * Main method
	 * 
	 * @param args command line arguments
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		BrokerService broker = BrokerFactory.createBroker("broker:(" + BROKER_URL + ")?" + BROKER_PROPS);
		broker.start(); // Start the broker

		ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(BROKER_URL);
		cf.setTrustAllPackages(true); // Trust all packages
		ActiveMQConnection connection = (ActiveMQConnection) cf.createConnection();

		connection.start(); // Start the connection
	}

}
