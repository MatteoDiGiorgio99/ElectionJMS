
package it.unipr.digiorgio;

import java.io.Serializable;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.activemq.ActiveMQConnectionFactory;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.ObjectMessage;

/**
 * The {@code ElectionManager} class in Java implements a distributed election algorithm using JMS for
 * coordinating processes and electing a coordinator.
 * The Coordinator node is elected based on Ring Algorithm.
 * The class implements the {@code Manager} interface and the {@code MessageListener} interface.

 * @author Matteo Di Giorgio 353719
 */

public class ElectionManager implements Manager, MessageListener {

	private Integer pid = null; // Process ID
	private Boolean coordinator = null; // Coordinator status
	private Integer pidCoordinator = null; // Coordinator PID
	private ArrayList<Integer> pids; // List of PIDs
	private static final int timeout = 500; // Timeout for the response
	boolean isResponse; // Flag for the response
	private MessageManagerImpl messageManager = null; // Message Manager
	private boolean down = false; // Status of the node
	private boolean election = false; // Status of the election
	private boolean coordination = false; // Status of the coordination

	/**
	 * Set the PID of the node
	 * 
	 * @param pid unique identifier of the node
	 * 
	 */
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	
	/**
	 * Set the list of PIDs of the nodes
	 * 
	 * @param pids list of PIDs
	 */
	public void setPids(ArrayList<Integer> pids) {
		Collections.sort(pids);
		this.pids = new ArrayList<Integer>(pids);
	}

	/**
	 * Get the PID of the node
	 * 
	 * @return the coordinator
	 */
	public Boolean getCoordinator() {
		return this.coordinator;
	}

	/**
	 * Get the PID of the coordinator
	 * 
	 * @return the PID of the coordinator
	 */
	public Integer getPidCoordinator() {
		return this.pidCoordinator;
	}


	/**
	 * Set the status of the node
	 * 
	 * @param down status of the node
	 */
	public void setDown(boolean down) {
		this.down = down;
	}

	/**
	 * Get the status of the election
	 * 
	 * @return the status of the election
	 */
	public boolean statusElection() {
		return election;
	}

	/**
	 * Constructor of the class
	 * 
	 * @param cf ActiveMQConnectionFactory
	 * @throws JMSException
	 */
	public ElectionManager(ActiveMQConnectionFactory cf) throws JMSException {
		this.messageManager = new MessageManagerImpl(cf);
		this.messageManager.start();
	}
	
	/**
	 * Set the coordinator of the node
	 * 
	 * @param c              status of the coordinator
	 * @param pidCoordinator PID of the coordinator
	 */
	public void setCoordinator(Boolean c, Integer pidCoordinator) {
		if (down)
			return;
		Integer tmp = this.pidCoordinator;

		this.coordinator = c;
		this.pidCoordinator = pidCoordinator;

		if (tmp == this.pidCoordinator) {
			return;
		}

		LocalTime currentTime = LocalTime.now(); // Get the current time
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss"); // Format the time
		String formattedTime = currentTime.format(formatter); // String of the formatted time

		System.out.println("\n");
		System.out.println("My PID: " + this.pid);

		if (this.pidCoordinator != null) {
			System.out.println(
					"\u001B[33mCoordinator PID: " + this.pidCoordinator + ", Time: " + formattedTime + "\u001B[0m");
		} else {
			System.out.println("\u001B[33mCoordinator PID: null\u001B[0m");
		}
	}
	

	/**
	 * Find the index of the next PID in the list
	 * 
	 * @param pids      list of PIDs
	 * @param targetPid PID to find
	 * @return index of the next PID
	 */
	public int findIndexOfNextPid(ArrayList<Integer> pids, int targetPid) {
		for (int i = 0; i < pids.size(); i++) {
			if (pids.get(i) == targetPid) {
				if (pids.size() - 1 == i)
					return 0;
				else
					return i + 1;
			}
		}
		// Return -1 if the target PID is not found in the list
		return -1;
	}
	
	/**
	 * Send the list of PIDs to the next node
	 * 
	 * @param list  list of PIDs
	 * @param i index of the next node
	 * @param rt    type of the request
	 */
	private void ForwardPids(ArrayList<Integer> list, int i, Type rt) {
		
		if (this.down) // Check the status of the node
			return;
		
		if (!this.election) // Check the status of the election
			return;

		int p = this.pids.get(i);
		if (p == this.pid)
			return;

		try {
			
			this.isResponse = false;
			this.messageManager.send("election_" + p, list, rt); // election message
			this.waitController();
			

		} catch (JMSException e) {
			
			e.printStackTrace();
			
		} catch (InterruptedException e) {
			
			e.printStackTrace();
			
		}
		// Process the response
		if (this.isResponse) {
			
			this.isResponse = false; // Reset flag
			
		} else {
			
			if (this.pids.size() - 1 == i)
			{
				this.ForwardPids(list, 0, rt);
			}else
				this.ForwardPids(list, i + 1, rt);
		}
	}
	
	/**
	 * Set the response flag
	 */
	public synchronized void setUpReply() {
		this.isResponse = true;
		notify(); // Notify the waiting thread
	}

	/**
	 * Wait for the response or the timeout
	 * 
	 * @throws InterruptedException
	 */
	public synchronized void waitController() throws InterruptedException {
		if (!this.isResponse) {
			
			wait(timeout); // Wait for the response or the timeout
			
		}
	}

	/**
	 * Start the election algorithm
	 */
	public void election() {

		System.out.println("\n===============================");
		System.out.println("\u001B[1;4mELECTION\u001B[0m");
		System.out.println("\n");

		this.election = true;
		this.coordination = false;
		this.setCoordinator(false, null);
		
		if (this.pids == null) // Check the list of PIDs
			return;

		if (this.down) // Check the status of the node
			return;
	

		ArrayList<Integer> list = new ArrayList<>();
		list.add(this.pid); // Add the PID of the node to the list

		Integer index = this.findIndexOfNextPid(this.pids, this.pid);
		this.ForwardPids(list, index, Type.election_message); // send the list of PIDs to the next node

	}


	@Override
	public void onMessage(Message m) {
		if (this.down)
			return;
		try {
			if (m instanceof ObjectMessage) {
				ObjectMessage objectMessage = (ObjectMessage) m;
				Serializable message = objectMessage.getObject();
				Type type_message = (Type) ((RequestHandler) message).type;

				switch (type_message) {
				
					case acknowledge:
						if (this.pidCoordinator != null) {
							
							this.election = false;
							this.coordination = false;
							
						}
						
						this.setUpReply();
						break;

					case election_message:
						
						// Response to election message
						String resPid = "election_" + m.getJMSCorrelationID().split("@")[0]; // Get the PID of the node
						this.messageManager.send(resPid, this.pid, Type.acknowledge);

						@SuppressWarnings("unchecked")
						ArrayList<Integer> list = (ArrayList<Integer>) ((RequestHandler) message).obj;
						
						int maxOfList = Collections.max(list);
						int ifNodeAddedChecker = this.findIndexOfNextPid(list, this.pid);
						int i = this.findIndexOfNextPid(this.pids, this.pid);

						/*
						 * If the node has already been added, it's time to coordinate all nodes and set the new coordinator.
						 * If the node has finished coordinating and the list contains the node's ID, 
						 * the node does not propagate the list.
						 */
						if (ifNodeAddedChecker != -1) {
							
							if (!this.coordination) {
								
								this.coordination = true;
								boolean flag_coordinatore = false;
								
								if (this.pid == maxOfList)
									flag_coordinatore = true;
								this.setCoordinator(flag_coordinatore, maxOfList);
								this.ForwardPids(list, i, Type.election_message);
							}
							
							return;
						}

						/*
						 * If the node is not already added we add the node pid to the list and
						 * propagate the list to the next node.
						 */
						this.election = true;
						this.coordination = false;

						list.add(this.pid);
						
						this.ForwardPids(list, i, Type.election_message);

						break;


					default:
						break;
				}
			}
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void start() throws JMSException {
		
		this.messageManager.listenerReceive(this);
		this.messageManager.receive("election_" + this.pid.toString());
		
	}

	@Override
	public void close() throws JMSException {
		this.messageManager.close();

	}
}
