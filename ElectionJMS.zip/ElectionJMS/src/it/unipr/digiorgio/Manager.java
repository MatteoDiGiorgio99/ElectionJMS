
package it.unipr.digiorgio;

import jakarta.jms.JMSException;

/** This class is defining a Java interface named {@code Manager} within the package
`it.unipr.digiorgio`. The interface has two abstract methods `start()` and `close()` that both throw
a `JMSException`. This interface likely represents a contract that classes implementing it must
adhere to by providing implementations for the `start()` and `close()` methods.

@author Matteo Di Giorgio 353719
*/

public interface Manager {
	/**
	 * Start the manager
	 * 
	 * @throws JMSException
	 */
	public void start() throws JMSException;

	/**
	 * Close the manager
	 * 
	 * @throws JMSException
	 */
	public void close() throws JMSException;
}
