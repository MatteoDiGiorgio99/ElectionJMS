
package it.unipr.digiorgio;

import java.io.Serializable;
import jakarta.jms.JMSException;
import jakarta.jms.MessageListener;
import jakarta.jms.QueueSession;

/**  This class is defining a Java interface named {@code MessageManager} within the package
`it.unipr.digiorgio`. The interface includes several methods related to messaging operations using
Java Message Service (JMS).

@author Matteo Di Giorgio 353719
*/

public interface MessageManager {
	/**
	 * Get the Queue Session
	 * 
	 * @return the Queue Session
	 */
	public QueueSession getQueueSession();

	/**
	 * Publish a message to a topic
	 * 
	 * @param topic_name the name of the topic
	 * @param obj        the object to publish
	 * @param type       the type of the request
	 * @throws JMSException 
	 */
	public void publish(String topic_name, Serializable obj, Type type) throws JMSException;

	/**
	 * Subscribe to a topic
	 * 
	 * @param topic_name the name of the topic
	 * @throws JMSException
	 */
	public void subscribe(String topic_name) throws JMSException;
	

	/**
	 * Send a message to a queue
	 * 
	 * @param queue_name the name of the queue
	 * @param obj        the object to send
	 * @param type       the type of the request
	 * @throws JMSException
	 */
	public void send(String queue_name, Serializable obj, Type type) throws JMSException;

	/**
	 * Receive a message from a queue
	 * 
	 * @param queue_name the name of the queue
	 * @throws JMSException
	 */
	public void receive(String queue_name) throws JMSException;


	/**
	 * Set the message listener for the subscription
	 * 
	 * @param messageListener the message listener
	 */
	public void listenerSub(MessageListener messageListener);
	
	/**
	 * Set the message listener for the sending
	 * 
	 * @param customOnMessage the message listener
	 */
	public void listenerSend(MessageListener customOnMessage);

	/**
	 * Set the message listener for the reception
	 * 
	 * @param customOnMessage the message listener
	 */
	public void listenerReceive(MessageListener customOnMessage);

	
}
