
package it.unipr.digiorgio;

import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageListener;
import jakarta.jms.MessageProducer;
import jakarta.jms.ObjectMessage;
import jakarta.jms.Queue;
import jakarta.jms.QueueReceiver;
import jakarta.jms.QueueSession;
import jakarta.jms.Session;
import jakarta.jms.Topic;
import jakarta.jms.TopicPublisher;
import jakarta.jms.TopicSession;
import jakarta.jms.TopicSubscriber;

import java.io.Serializable;
import java.lang.management.ManagementFactory;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;


/**
 * The {@code MessageManagerImpl} class is an implementation of a message manager that handles sending,
 * receiving, subscribing, and publishing messages using JMS with ActiveMQ.
 * The class implements the {@code Manager} interface and the {@code MessageManager} interface.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class MessageManagerImpl implements Manager, MessageManager {

	// The message listeners
	private MessageListener sub = null; 
	private MessageListener rec = null; 
	private MessageListener send = null;  
	
	// The queue and topic sessions
	private QueueSession queueSession = null;
	private TopicSession topicSession = null;
	private ActiveMQConnection cn = null; 

	/**
	 * Constructor for the class.
	 * 
	 * @param cf the connection factory
	 * @throws JMSException
	 */
	public MessageManagerImpl(ActiveMQConnectionFactory cf) throws JMSException {
		cf.setTrustAllPackages(true);
		cn = (ActiveMQConnection) cf.createConnection();
	}

	@Override
	public void start() throws JMSException {
		cn.start();
		queueSession = cn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
		topicSession = cn.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
	}

	@Override
	public void close() throws JMSException {
		if (cn != null) {
			cn.close();
		}
	}

	@Override
	public QueueSession getQueueSession() {
		return this.queueSession;
	}

	@Override
	public void publish(String topic_name, Serializable obj, Type type) throws JMSException {
		
		topicSession = cn.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
		Topic topic = topicSession.createTopic(topic_name);
		TopicPublisher publisher = topicSession.createPublisher(topic);

		ObjectMessage objectMessage = topicSession.createObjectMessage();
		objectMessage.setObject(new RequestHandler(obj, type));

		publisher.publish(objectMessage);
		publisher.publish(topicSession.createMessage());
	}

	@Override
	public void subscribe(String topic_name) throws JMSException {

		topicSession = cn.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
		Topic topic = topicSession.createTopic(topic_name);
		TopicSubscriber subscriber = topicSession.createSubscriber(topic);

		if (this.sub != null)
			subscriber.setMessageListener(sub);
	}
	
	@Override
	public void send(String queue_name, Serializable obj, Type type) throws JMSException {
		
		Destination serverQueue = queueSession.createQueue(queue_name);
		Destination tempDest = queueSession.createTemporaryQueue();
		
		MessageProducer producer = queueSession.createProducer(serverQueue);
		MessageConsumer consumer = queueSession.createConsumer(tempDest);
		ObjectMessage request = queueSession.createObjectMessage();

		request.setObject(new RequestHandler(obj, type));
		request.setJMSReplyTo(tempDest);
		String processName = ManagementFactory.getRuntimeMXBean().getName();
		request.setJMSCorrelationID(processName);

		producer.send(request);

		if (this.send != null)
			consumer.setMessageListener(send);

		producer.close();
	}

	@Override
	public void receive(String queue_name) throws JMSException {

		Queue queue = queueSession.createQueue(queue_name);
		QueueReceiver receiver = queueSession.createReceiver(queue);
		MessageConsumer consumer = queueSession.createConsumer(queue);
		
		if (this.rec != null)
			consumer.setMessageListener(rec);
		receiver.close();
	}



	@Override
	public void listenerSub(MessageListener messageListener) {
		this.sub = messageListener;
	}
	
	@Override
	public void listenerSend(MessageListener customOnMessage) {
		this.send = customOnMessage;
	}

	@Override
	public void listenerReceive(MessageListener customOnMessage) {
		this.rec = customOnMessage;
	}

	
}
