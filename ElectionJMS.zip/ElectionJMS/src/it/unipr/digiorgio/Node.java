
package it.unipr.digiorgio;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.activemq.ActiveMQConnectionFactory;

/**
 * The {@code Node} class in Java manages a network of nodes with functionalities for node coordination,
 * resource management, and leader election.
 * 
 * Includes methods for starting and closing the node, as well as managing the node's state and
 * interactions with other nodes in the network.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class Node {
	private static int NODES = 0; // Number of nodes
	private static final double A_prob = 0.35; // Probability of a node going down (35%)
	private static final double B_prob = 0.65; // Probability of a node coming back up (65%)
	private static final String BROKER_URL = "tcp://localhost:61616";

	private static final long BLOCK_PERIOD = 60000; // Block period in milliseconds (1 minute)
	private static long lastInactiveTime = 0; // Timestamp of the last inactive state of the node

	/**
	 * Main method
	 * 
	 * @param args command line arguments
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(BROKER_URL);

		NodesManager nodes = new NodesManager(cf);
		nodes.start();

		System.out.println("Waiting for nodes to join...");
		while (NODES == 0) {
			Thread.sleep(1000);
			NODES = nodes.getSize();
		}
		System.out.println(NODES + " nodes have joined.");

		ResourcesManager resouces_manager = new ResourcesManager(cf); // Create a new ResourcesManager object
		resouces_manager.setPid(nodes.getPid());
		resouces_manager.start();

		ElectionManager election_manager = new ElectionManager(cf); // Create a new ElectionManager object
		election_manager.setPid(nodes.getPid());
		election_manager.setPids(nodes.getPids());
		election_manager.start();

		// Request user input to start the algorithm
		System.out.println("Press any key and Enter to start the algorithm:");
		try (Scanner scanner = new Scanner(System.in)) {
			scanner.nextLine(); // Wait for user input
		}
		System.out.println("Initiating node...");

		ArrayList<Integer> pids = new ArrayList<Integer>(nodes.getPids());
		Thread.sleep(1000);
		election_manager.election(); // Start the election process

		boolean down = false;
		int updowncount = 0; // Number of times the node has gone down and come back up

		while (resouces_manager.endExecution()) {
			
			election_manager.setPids(nodes.getPids());
			ArrayList<Integer> list = new ArrayList<Integer>(nodes.getPids());
			
			if (pids.size() == 1) 
			{
				
				System.out.println("\033[1;31;5m" + "I am the last node!!" + "\033[0m");
				nodes.close();
				resouces_manager.close();
				election_manager.close();
				System.exit(0);
			}

			// Check if the list of nodes has changed
			if (!nodes.areEqualLists(pids, list)) {
				pids = list;
				election_manager.election();
			}

			// Check if the timeout coordinator flag is set
			if (resouces_manager.isTimeoutCoordinator()) {
				resouces_manager.setTimeoutCoordinator(false);
				election_manager.election();
			}

			resouces_manager.setPidCoordinator(election_manager.getPidCoordinator());
			resouces_manager.setCoordinator(election_manager.getCoordinator());

			LocalTime currentTime = LocalTime.now(); // Get the current time
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss"); // Format the time
			String formattedTime = currentTime.format(formatter); // String representation of the time

			if (down) {
				// Check if the node should come back up
				if (nodes.Probability(B_prob)) {
					
					down = false;
					updowncount++;
					election_manager.setDown(down);
					resouces_manager.setDown(down);
					
					System.out.println("\n===============================");
					System.out.println("\033[1;32m" + "Nodes Active " + formattedTime + "\033[0m");
					System.out.println("===============================");
					
					election_manager.election();
				}
			} else {
				
				resouces_manager.setPidCoordinator(election_manager.getPidCoordinator());
				resouces_manager.setCoordinator(election_manager.getCoordinator());
				resouces_manager.execute();

				// Check if the node should go down
				if (nodes.Probability(A_prob) && updowncount < 1) {
					
					down = true;
					election_manager.setDown(down);
					resouces_manager.setDown(down);
					
					System.out.println("\n===============================");
					System.out.println("\033[1;31;5m" + "Nodes Inactive " + formattedTime + "\033[0m");
					System.out.println("===============================");

					lastInactiveTime = System.currentTimeMillis();
					Thread.sleep(5000);
				}
				/*
				 * Check if the node has remained inactive for a duration longer than the
				 * blocking period
				 */
				else
				if (System.currentTimeMillis() - lastInactiveTime >= BLOCK_PERIOD) {
					// Reset the inactive time
					updowncount = 0;
				}

				Thread.sleep(100);
			}

			Thread.sleep(500);
		}

		nodes.close();
		resouces_manager.close();
		election_manager.close();

		System.exit(0);
	}

}
