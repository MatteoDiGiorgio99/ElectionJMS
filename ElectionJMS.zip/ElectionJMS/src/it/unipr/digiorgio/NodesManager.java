
package it.unipr.digiorgio;

import java.io.Serializable;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import org.apache.activemq.ActiveMQConnectionFactory;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.ObjectMessage;

/**
 * The {@code NodesManager} class in Java manages a list of process IDs, handles messaging between nodes, and
 * provides methods for managing the list and checking probabilities.
 * 
 * Implements the {@code Manager} interface and the {@code MessageListener} interface to handle messaging
 * 
 * @author Matteo Di Giorgio 353719
 */
public class NodesManager implements Manager, MessageListener {

	private Integer pid = null; // Process ID
	public ArrayList<Integer> pids = new ArrayList<>(); // List of process IDs
	private MessageManagerImpl messageManager = null; // Message manager
	private Random random = new Random(); // Random number generator

	/**
	 * Constructor for the class.
	 * 
	 * @param cf the connection factory
	 * @throws JMSException
	 */
	public NodesManager(ActiveMQConnectionFactory cf) throws JMSException {
		this.messageManager = new MessageManagerImpl(cf);
		messageManager.start();
	}

	/**
	 * Method to get the size of the list of process IDs.
	 * 
	 * @return the size of the list
	 */
	public int getSize() {
		return this.pids.size();
	}

	/**
	 * Method to get the process ID of the node.
	 * 
	 * @return the process ID
	 */
	public Integer getPid() {
		return this.pid;
	}

	/**
	 * Method to get the list of process IDs.
	 * 
	 * @return the list of process IDs
	 */
	public ArrayList<Integer> getPids() {
		return this.pids;
	}

	/**
	 * Method to get the maximum process ID in the list.
	 * 
	 * @return the maximum process ID
	 */
	public Integer getMaxPidOfTheList() {

		if (this.pids.isEmpty()) {
			throw new IllegalArgumentException("List is empty");
		}
		// Initialize max to the first element of the list
		int max = this.pids.get(0);

		// Iterate through the list starting from the second element
		for (int i = 1; i < this.pids.size(); i++) {
			// Update max if the current element is greater
			if (this.pids.get(i) > max) {
				max = this.pids.get(i);
			}
		}
		return max;
	}
	
	/**
	 * 
	 * Method to compare two lists of integers.
	 * 
	 * @param firstList the first list
	 * @param lastList the second list
	 * 
	 * @return true if the lists are equal, false otherwise
	 */
	public boolean areEqualLists(ArrayList<Integer> firstList, ArrayList<Integer> lastList) {
		if (firstList.size() > lastList.size()) {
			ArrayList<Integer> tmp = new ArrayList<Integer>(lastList);
			lastList = new ArrayList<Integer>(firstList);
			firstList = new ArrayList<Integer>(tmp);
		}
		ArrayList<Integer> result = new ArrayList<Integer>(lastList);
		result.removeAll(new HashSet<>(firstList));
		if (result.size() == 0)
			return true;
		else
			return false;
	}

	/**
	 * Method to check if a random number is less than a specified probability.
	 * 
	 * @param probability the probability
	 * @return true if the random number is less than the probability, false
	 *         otherwise
	 */
	public boolean Probability(double probability) {
		if (probability < 0 || probability > 1) {
			throw new IllegalArgumentException("Set Prob between 0 and 1");
		}
	
		// Generate a random double between 0 and 1 with 2 decimal places
		double var = Math.round(random.nextDouble() * 100.0) / 100.0;
		// System.out.println("Random value: " + var + ", Probability: " +probability);
		// Return true if the var is less than the specified probability
		return var < probability;
	}


	@Override
	public void start() throws JMSException {
		
		this.messageManager.listenerSub(this);
		this.messageManager.subscribe("nodesList");

		String processName = ManagementFactory.getRuntimeMXBean().getName();
		System.out.println("Process Name: " + processName);
		
		// Extract the process ID from the name
		this.pid = Integer.parseInt(processName.split("@")[0]);
		this.pids.add(pid);
		this.messageManager.publish("nodesList", (Serializable) pid, Type.subscribe); // Subscribe to the list
		
		random.setSeed(this.pid); // Set the seed for the random number generator
		
	}

	@Override
	public void close() throws JMSException {
		
		this.messageManager.publish("nodesList", (Serializable) this.pid, Type.unsubscribe); // Unsubscribe from the list
		System.out.println("\033[1;31;5m" + "Unsubscribed from the group." + "\033[0m");
		
	}

	@Override
	public void onMessage(Message message) {
		try {
			if (message instanceof ObjectMessage) {
				ObjectMessage objectMessage = (ObjectMessage) message;
				Serializable rh = objectMessage.getObject();
				Type type_message = (Type) ((RequestHandler) rh).type;

				switch (type_message) {

					case subscribe: // Add a new node to the list
						
						Integer pid = (Integer) ((RequestHandler) rh).obj;
						
						if (this.pids.contains(pid)) {
							
							System.out.println("Pid check_list positive!"); // Check if the pid is already in the list
							
						} else {
							
							this.pids.add(pid);
							System.out.println("Pid List: " + this.pids);
							this.messageManager.publish("nodesList", (Serializable) this.pids, Type.append_node);
							
						}
						break;

					case unsubscribe: // Remove a node from the list

						Integer pid1 = (Integer) ((RequestHandler) rh).obj;
						
						if (this.pids.contains(pid1)) {
							
							this.pids.remove(pid1);
							if (this.pids != null)
								System.out.println("Pid List: " + this.pids);
							
						} else {
							
							System.out.println("Pid check_remove positive"); // Check if the pid is already removed
						}
						break;

					case append_node: // Update the list of process IDs

						@SuppressWarnings("unchecked")
						ArrayList<Integer> pids = (ArrayList<Integer>) ((RequestHandler) rh).obj;
						
						if (this.pids.size() >= pids.size()) {
							
							System.out.println("My list update: " + this.pids);
							System.out.println("Press any key and Enter to start the algorithm:");
							
						} else {
							
							this.pids = new ArrayList<>(pids);
							System.out.println("Update list: " + this.pids);
							
						}
						break;

					default:
						break;
				}
			}
		} catch (JMSException e) {
			e.printStackTrace();

		}
	}

}
