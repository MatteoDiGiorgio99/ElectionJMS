
package it.unipr.digiorgio;

import java.io.Serializable;

/**
 * The {@code RequestHandler} class in Java is used for handling requests with a specified object and type.
 * 
 * The class is used to handle requests between nodes in the network.
 * Implements the {@code Serializable} interface.
 * 
 * @author Matteo Di Giorgio 353719
 */

public class RequestHandler implements Serializable {

	private static final long serialVersionUID = 1L; // Serial version UID
	public Serializable obj = null; // Object to handle 
	public Type type = null;	// Type of request

	/**
	 * Constructor for the class.
	 * 
	 * @param obj  the object to handle
	 * @param type the type of request
	 */
	public RequestHandler(Serializable obj, Type type) {
		this.obj = obj;
		this.type = type;
	}
}
