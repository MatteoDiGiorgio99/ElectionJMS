
package it.unipr.digiorgio;

import java.io.Serializable;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import org.apache.activemq.ActiveMQConnectionFactory;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.ObjectMessage;

/**
 * The {@code ResourcesManager} class in Java manages resource requests and responses between nodes in a
 * distributed system.
 * 
 * The class implements the {@code Manager} interface and the {@code MessageListener} interface.
 * 
 * @author Matteo Di Giorgio 353719
 */
public class ResourcesManager implements Manager, MessageListener {

	private Integer pid = null; // Process ID
	private Random random = new Random(); // Random number generator

	private MessageManagerImpl messageHandler = null; // Message manager

	private int taskCounter = 0; // Number of tasks executed by the node
	private static final int TASKS = 100; // Number of tasks to execute
	private static final double C_prob = 0.8; // Probability of the coordinator granting the resource (80%)

	private static final int maxTimeout = 20000; // Maximum timeout for the response
	private boolean isResponse; // Flag for the response

	private Integer pidCoordinator = null; // Coordinator PID
	private boolean checkTimeout = false; // Flag for the timeout
	private Boolean coordinator = null; // Coordinator status
	private Boolean down = false; // Node status

	/**
	 * Set the PID of the node
	 * 
	 * @param pid unique identifier of the node
	 * 
	 */
	public void setPid(Integer pid) {
		this.pid = pid;
	}

	/**
	 * Set the PID of the coordinator
	 * 
	 * @param pidCoordinator unique identifier of the coordinator
	 * 
	 */
	public void setPidCoordinator(Integer pidCoordinator) {
		this.pidCoordinator = pidCoordinator;
	}

	/**
	 * Get timeout coordinator status
	 * 
	 * @return the timeout coordinator status
	 */
	public boolean isTimeoutCoordinator() {
		return checkTimeout;
	}

	/**
	 * Set coordinator timeout status
	 * 
	 * @param timeout the timeout coordinator status
	 * 
	 */
	public void setTimeoutCoordinator(boolean timeout) {
		this.checkTimeout = timeout;
	}

	/**
	 * Set coordinator
	 * 
	 * @param coordinator the coordinator status
	 */
	public void setCoordinator(Boolean coordinator) {
		this.coordinator = coordinator;
	}

	/**
	 * Set node status
	 * 
	 * @param down the node status
	 */
	public void setDown(Boolean down) {
		this.down = down;
	}

	/**
	 * Constructor for the class.
	 * 
	 * @param cf the connection factory
	 * @throws JMSException
	 */
	public ResourcesManager(ActiveMQConnectionFactory cf) throws JMSException {
		this.messageHandler = new MessageManagerImpl(cf);
		this.messageHandler.start();
	}



	/**
	 * Method to execute the resource request.
	 * 
	 * @throws InterruptedException
	 * @throws JMSException
	 */
	public void execute() throws InterruptedException, JMSException {
		
		if (this.down) // Check if the node is down
			return;
		
		if (this.coordinator == null || this.pidCoordinator == null) // Check if the coordinator is set
			return;
		
		if (!this.coordinator) {
			
			System.out.println("I am not the coordinator. Send request.");
			this.messageHandler.send("resource_" + this.pidCoordinator, this.pid, Type.request_resource);

			// Wait for the response or timeout
			System.out.println("Waiting for response...");
			waitController();
			System.out.println("Response received.");

			// Process the response
			if (this.isResponse) {
				this.isResponse = false; // Reset flag
			} else {
				System.out.println("\nTimeout!!!");
				System.out.println("\u001B[1;31m\u001B[4mCoordinator has been unresponsive for a while, possibly inactive. Initiating Election.\u001B[0m");
				
				this.setCoordinator(null);
				this.setPidCoordinator(null);
				this.checkTimeout = true;
			}
		}
	}

	/**
	 * Method to set the response flag.
	 * 
	 * @return set the response flag
	 */
	private synchronized void setResponse() {
		this.isResponse = true;
		notify(); // Notify the waiting thread
	}

	/**
	 * Method to wait for the response or the timeout.
	 * 
	 * @throws InterruptedException
	 */
	private synchronized void waitController() throws InterruptedException {
		if (!this.isResponse) {
			wait(maxTimeout); // Wait for the response or timeout
		}
	}

	/**
	 * Method to check if the execution has ended.
	 * 
	 * @return true if the execution has ended, false otherwise
	 */
	public boolean endExecution() {
		return this.taskCounter < ResourcesManager.TASKS;
	}
	
	/**
	 * Method to generate a random number and compare it with a specified
	 * probability.
	 * 
	 * @param probability the probability to compare with
	 * 
	 * @return true if the random number is less than the probability, false
	 *         otherwise
	 */
	public boolean Probability(double probability) {
		if (probability < 0 || probability > 1) {
			throw new IllegalArgumentException("Set Prob between 0 and 1");
		}

		// Generate a random double between 0 and 1 with 2 decimal places
		double var = Math.round(random.nextDouble() * 100.0) / 100.0;
		// System.out.println("Random value: " + var + ", Probability: " +
		// probability);
		// Return true if the var is less than the specified probability
		return var < probability;
	}
	
	@Override
	public void start() throws JMSException {
		
		this.messageHandler.listenerReceive(this);
		this.messageHandler.receive("resource_" + this.pid); // Subscribe to the resource queue
		if (this.pid != null)
			random.setSeed(this.pid);
	}
	
	@Override
	public void close() throws JMSException {
		this.messageHandler.close();
	}

	@Override
	public void onMessage(Message message) {
		if (this.down)
			return;
		if (this.coordinator == null || this.pidCoordinator == null)
			return;
		try {
			if (message instanceof ObjectMessage) {
				
				ObjectMessage objectMessage = (ObjectMessage) message;
				Serializable request_handler = objectMessage.getObject();
				Type type_message = (Type) ((RequestHandler) request_handler).type;
				
				System.out.println("Message received: " + type_message);
				
				switch (type_message) {

					case request_resource: // Resource request

						if (this.coordinator) {
							
							Integer pid = (Integer) ((RequestHandler) request_handler).obj;
							String resPid = "resource_" + pid;
							Boolean response = Probability(ResourcesManager.C_prob);
							
							System.out.println("Resource request from PID " + pid + ". Response: " + response);
							this.messageHandler.send(resPid, response, Type.response_resource);
						}
						break;

					case response_resource: // Resource response

						this.setResponse();

						// Formatting of current time to check the nodes coordination
						LocalTime currentTime = LocalTime.now();
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
						String formattedTime = currentTime.format(formatter);

						Boolean response = (Boolean) ((RequestHandler) request_handler).obj;
						System.out.println("Coordinator " + this.pidCoordinator + " response: " + response + " " + formattedTime);

						if (response) {
							
							System.out.println("\n===============================");
							System.out.println("Resource granted. EXECUTING TASK...");
							this.taskCounter++;
							System.out.println("Executed task: " + this.taskCounter + "/" + ResourcesManager.TASKS);
							System.out.println("===============================");
							Thread.sleep(100);
							
						} else {
							
							System.out.println("\n===============================");
							System.out.println("Resource NOT granted. RETRYING...");
							System.out.println("===============================");
							Thread.sleep(100);
						}
						break;

					default:

						break;
				}
			}
		} catch (JMSException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}



}
