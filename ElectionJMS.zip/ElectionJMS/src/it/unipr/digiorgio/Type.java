
package it.unipr.digiorgio;

/**  This class is defining a Java enum called {@code Type} within the `it.unipr.digiorgio`
package. The enum contains several constants representing different types of requests, such as
`subscribe`, `unsubscribe`, `append_node`, `election`, `acknowledge`, `request_resource`, and
 `response_resource`.
*
* @author Matteo Di Giorgio 353719
*/
public enum Type {
	/**
	 * Subscribe to the list of process IDs
	 */
	subscribe, 
	/**
	 * Unsubscribe from the list of process IDs
	 */
	unsubscribe,
	/**
	 * Append a node to the list of process IDs
	 */
	append_node,
	/**
	 * Start an election
	 */
	election_message,
	/**
	 * Acknowledge the election
	 */
	acknowledge,
	/**
	 * Request a resource
	 */
	request_resource,
	/**
	 * Respond to a resource request
	 */
	response_resource,
}
