
/**
 * The goal is to implement a system involving a group of nodes, where one of the nodes acts as the coordinator
 * and the others act as executors.
 * Each node can be active or inactive and switches its state from active to inactive with probability A, and from
 * inactive to active with probability B.
 * The coordinator is identified through an election algorithm (Bully or Ring), and elections are triggered by:
 * 1) an executor, when it believes the coordinator is no longer active, or
 * 2) a node when it becomes active again.
 * Executors, besides recognizing the possible inactivity of the coordinator, are tasked with executing sequences of tasks.
 * Task execution is possible by exchanging messages with the coordinator: the executor asks the coordinator if it can
 * execute the task, and the coordinator responds positively with probability C.
 * In particular, if the response is not positive, then the executor waits for a random time and retries the request
 * to the coordinator.
 * The coordinator's only task is to approve or disapprove the execution request of a task.
 * Each executor terminates its activity after executing 100 tasks. The system concludes its activities when the system
 * is represented by a single node.
 * 
 * @author Matteo Di Giorgio 353719
 */

package it.unipr.digiorgio;